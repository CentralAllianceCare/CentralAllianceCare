export default function OpenHour() {
  return (
    <>
      <div className="col-lg-3 col-md-6 col-12">
        <div className="single-footer">
          <h2>Open Hours</h2>
          <p>
            Lorem ipsum dolor sit ame consectetur adipisicing elit do eiusmod
            tempor incididunt.
          </p>
          <ul className="time-sidual">
            <li className="day">
              Monday - Fridayp <span>8.00-20.00</span>
            </li>
            <li className="day">
              Saturday <span>9.00-18.30</span>
            </li>
            <li className="day">
              Monday - Thusday <span>9.00-15.00</span>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}
