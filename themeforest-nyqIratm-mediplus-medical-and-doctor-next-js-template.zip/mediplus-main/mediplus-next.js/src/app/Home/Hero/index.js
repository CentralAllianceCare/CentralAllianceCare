import Sliders from "./Sliders";

export default function Hero({ sectionName }) {
  return (
    <>
      <Sliders sectionName={sectionName} />
    </>
  );
}
